import Cocoa

var sideOne:Float = 13.0 //Add 1st Side Here
var sideTwo:Float = 19.0 //Add 2nd Side Here

var greaterThan = abs(sideOne-sideTwo)
var lessThan = sideOne + sideTwo

print("\(greaterThan) < x < \(lessThan)") //prints compound inequality

var sum = greaterThan + lessThan
var avg = sum/2

var difference = abs(lessThan - avg)

print("|x - \(avg)| < \(difference)")

